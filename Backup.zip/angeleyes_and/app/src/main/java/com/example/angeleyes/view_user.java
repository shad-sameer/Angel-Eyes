package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class view_user extends AppCompatActivity {
    ListView user;
    FloatingActionButton fbadd;
    String[] user_id,user_name,lid,caretaker_id,place,pincode,phone,post,district,housename,dob,gender,picture,email_id;


    @Override
    public void onBackPressed() {
        Intent ij=new Intent(getApplicationContext(),Vgome.class);
        startActivity(ij);
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_user);
        user=findViewById(R.id.lv);
        fbadd=findViewById(R.id.floatingActionButton);

        fbadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), caretaker_manage_user.class);
                startActivity(i);

            }
        });
        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        final String maclis=sh.getString("mac_list","");
        String uid=sh.getString("uid","");
        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5000/and_view_user";



        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        // response
                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                JSONArray js = jsonObj.getJSONArray("data");

                                lid = new String[js.length()];
                                user_name = new String[js.length()];
                                picture = new String[js.length()];
                                user_id = new String[js.length()];
                                caretaker_id = new String[js.length()];
                                place = new String[js.length()];
                                pincode = new String[js.length()];
                                post = new String[js.length()];
                                phone = new String[js.length()];
                                housename = new String[js.length()];
                                district = new String[js.length()];
                                email_id = new String[js.length()];
                                dob = new String[js.length()];
                                gender = new String[js.length()];

                                for (int i = 0; i < js.length(); i++){
                                    JSONObject object = js.getJSONObject(i);

                                    lid[i]=object.getString("lid");
                                    user_name[i]=object.getString("user_name");
                                    picture[i]=object.getString("picture");
                                    user_id[i]=object.getString("user_id");
                                    place[i]=object.getString("place");
                                    caretaker_id[i]=object.getString("caretaker_id");
                                    pincode[i]=object.getString("pincode");
                                    post[i]=object.getString("post");
                                    housename[i]=object.getString("housename");
                                    phone[i]=object.getString("phone");
                                    district[i]=object.getString("district");
                                    email_id[i]=object.getString("email_id");
                                    dob[i]=object.getString("dob");
                                    gender[i]=object.getString("gender");

                                }
                                user.setAdapter(new custom_caretaker_view_user(getApplicationContext(),user_id,user_name,lid,caretaker_id,place,pincode,phone,post,district,housename,dob,gender,picture,email_id));


                            }


                            // }
                            else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        }    catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();

                params.put("lid", sh.getString("lid",""));

                return params;
            }
        };

        int MY_SOCKET_TIMEOUT_MS=100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);
    }
}