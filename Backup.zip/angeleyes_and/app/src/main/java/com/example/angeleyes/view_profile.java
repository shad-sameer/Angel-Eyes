package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class view_profile extends AppCompatActivity implements View.OnClickListener {

    TextView tvname,tvgender,tvdob,tvphone,tvemail,tvhousename,tvplace,tvpost,tvpincode,tvdistrict;
    ImageView img;
    Button btn;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_profile);

        tvname=findViewById(R.id.textView24);
        tvgender=findViewById(R.id.textView25);
        tvdob=findViewById(R.id.textView26);
        tvphone=findViewById(R.id.textView27);
        tvemail=findViewById(R.id.textView28);
        tvhousename=findViewById(R.id.textView29);
        tvplace=findViewById(R.id.textView30);
        tvpost=findViewById(R.id.textView31);
        tvpincode=findViewById(R.id.textView32);
        tvdistrict=findViewById(R.id.textView33);
        btn=findViewById(R.id.button14);
        img=findViewById(R.id.imageView5);
btn.setOnClickListener(this);


        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        String hu = sh.getString("ip", "");
        String url = "http://" + hu + ":5000/and_caretaker_profile";


        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObj = new JSONObject(response);
                            if (jsonObj.getString("status").equalsIgnoreCase("ok")) {

                                tvname.setText(jsonObj.getString("name"));
                                tvgender.setText(jsonObj.getString("gender"));
                                tvdistrict.setText(jsonObj.getString("district"));
                                tvdob.setText(jsonObj.getString("dob"));
                                tvemail.setText(jsonObj.getString("email"));
                                tvhousename.setText(jsonObj.getString("housename"));
                                tvphone.setText(jsonObj.getString("phone"));
                                tvpincode.setText(jsonObj.getString("pincode"));
                                tvplace.setText(jsonObj.getString("place"));
                                tvpost.setText(jsonObj.getString("post"));

                            } else {
                                Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                            }

                        } catch (Exception e) {
                            Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // error
                        Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                    }
                }
        ) {

            //                value Passing android to python
            @Override
            protected Map<String, String> getParams() {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                Map<String, String> params = new HashMap<String, String>();

                params.put("lid", sh.getString("lid",""));


                return params;
            }
        };


        int MY_SOCKET_TIMEOUT_MS = 100000;

        postRequest.setRetryPolicy(new DefaultRetryPolicy(
                MY_SOCKET_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        requestQueue.add(postRequest);




    }

    @Override
    public void onClick(View view) {
        Intent i=new Intent(getApplicationContext(),caretaker_edit_profile.class);
        startActivity(i);
        SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        SharedPreferences.Editor ed=sh.edit();
        ed.putString("name",tvname.getText().toString());
        ed.putString("gender",tvgender.getText().toString());
        ed.putString("district",tvdistrict.getText().toString());
        ed.putString("dob",tvdob.getText().toString());
        ed.putString("email",tvemail.getText().toString());
        ed.putString("housename",tvhousename.getText().toString());
        ed.putString("phone",tvphone.getText().toString());
        ed.putString("pincode",tvpincode.getText().toString());
        ed.putString("post",tvpost.getText().toString());
        ed.putString("place",tvplace.getText().toString());

    }
}