package com.example.angeleyes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class custom_view_location_user extends BaseAdapter {
    String[] loc_id,lid,date,longitude,latitude;
    Context context;

    public custom_view_location_user(Context context, String[] loc_id, String[] lid, String[] date, String[] longitude, String[] latitude)
    {
        this.context=context;
        this.loc_id=loc_id;
        this.lid=lid;
        this.date=date;
        this.longitude=longitude;
        this.latitude=latitude;

    }
    @Override
    public int getCount() {
        return lid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View flv;

        if (view==null)
        {
            flv=inflater.inflate(R.layout.custom_view_location_user,null);
        }else{
            flv=(View) view;
        }
        TextView tvdate = flv.findViewById(R.id.textView15);
        TextView tvlongitude = flv.findViewById(R.id.textView17);
        TextView tvlatitude = flv.findViewById(R.id.textView18);
        tvdate.setText(date[i]);
        tvlongitude.setText(longitude[i]);
        tvlatitude.setText(latitude[i]);
        return flv;
    }
}
