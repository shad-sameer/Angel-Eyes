package com.example.angeleyes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class custom_caretaker_view_user extends BaseAdapter {
    String[]user_id,user_name,lid,caretaker_id,place,pincode,phone,post,district,housename,dob,gender,picture,email_id;
    Context context;
    public custom_caretaker_view_user(Context context, String[] user_id, String[] user_name, String[] lid, String[] caretaker_id, String[] place, String[] pincode, String[] phone, String[] post, String[] district, String[] housename, String[] dob, String[] gender, String[] picture, String[] email_id)
    {
        this.context=context;
        this.lid= lid;
        this.user_name=user_name;
        this.picture= picture;
        this.user_id= user_id;
        this.caretaker_id= caretaker_id;
        this.place= place;
        this.pincode=pincode;
        this.phone= phone;
        this.post= post;
        this.district= district;
        this.housename= housename;
        this.dob= dob;
        this.gender= gender;
        this.email_id= email_id;


    }
    @Override
    public int getCount() {
        return caretaker_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View flv;

        if (view==null)
        {
            flv=inflater.inflate(R.layout.custom_caretaker_view_user,null);
        }else{
            flv=(View) view;
        }
        TextView tvname = flv.findViewById(R.id.textView24);
        TextView tvplace = flv.findViewById(R.id.textView30);
        TextView tvpincode = flv.findViewById(R.id.textView32);
        TextView tvphone = flv.findViewById(R.id.textView27);
        TextView tvpost = flv.findViewById(R.id.textView31);
        TextView tvdistrict = flv.findViewById(R.id.textView33);
        TextView tvhousename = flv.findViewById(R.id.textView29);
        TextView tvdob = flv.findViewById(R.id.textView26);
        TextView tvgender = flv.findViewById(R.id.textView25);
        TextView tvemail = flv.findViewById(R.id.textView28);
        Button btnedit=flv.findViewById(R.id.button14);
        Button btndelete=flv.findViewById(R.id.button15);
        btnedit.setTag(i);
        btndelete.setTag(lid[i]);

        btnedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int index= (int) view.getTag();
                SharedPreferences sh= PreferenceManager.getDefaultSharedPreferences(context);
                SharedPreferences.Editor ed = sh.edit();
                ed.putString("name",user_name[index]);
                ed.putString("place",place[index]);
                ed.putString("pincode",pincode[index]);
                ed.putString("post",post[index]);
                ed.putString("phone",phone[index]);
                ed.putString("district",district[index]);
                ed.putString("housename",housename[index]);
                ed.putString("dob",dob[index]);
                ed.putString("gender",gender[index]);
                ed.putString("email",email_id[index]);
                ed.putString("ulid",lid[index]);
                ed.putString("picture",picture[index]);
                ed.commit();
                Intent i = new Intent(context, caretaker_edit_user.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);


                String url = sh.getString("url", "")+"/and_delete_user";



                RequestQueue requestQueue = Volley.newRequestQueue(context);
                StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                                // response
                                try {
                                    JSONObject jsonObj = new JSONObject(response);
                                    if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                        Intent i =new Intent(context,view_user.class);
                                        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                        context.startActivity(i);

                                    }


                                    // }
                                    else {
                                        Toast.makeText(context, "Not found", Toast.LENGTH_LONG).show();
                                    }

                                }    catch (Exception e) {
                                    Toast.makeText(context, "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                // error
                                Toast.makeText(context, "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() {
                        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("lid",view.getTag().toString());


                        return params;
                    }
                };

                int MY_SOCKET_TIMEOUT_MS=100000;

                postRequest.setRetryPolicy(new DefaultRetryPolicy(
                        MY_SOCKET_TIMEOUT_MS,
                        DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                        DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
                requestQueue.add(postRequest);


            }
        });

        ImageView img =  flv.findViewById(R.id.imageView5);

        tvname.setText(user_name[i]);
        tvplace.setText(place[i]);
        tvdistrict.setText(district[i]);
        tvdob.setText(dob[i]);
        tvemail.setText(email_id[i]);
        tvgender.setText(gender[i]);
        tvhousename.setText(housename[i]);
        tvpincode.setText(pincode[i]);
        tvpost.setText(post[i]);
        tvphone.setText(phone[i]);

        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(context);
        String url = sh.getString("url", "")+picture[i];
        Picasso.with(context).load(url).into(img);
        return flv;
    }
}
