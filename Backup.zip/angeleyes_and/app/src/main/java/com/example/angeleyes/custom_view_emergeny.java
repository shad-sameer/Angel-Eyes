package com.example.angeleyes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class custom_view_emergeny extends BaseAdapter {
    String[] lid,date,time,longitude,latitude,emergency_id,name;
    Context context;

    public custom_view_emergeny(Context context, String[] lid, String[] date,String[] time,String[] longitude,String[] latitude,String[] emergency_id, String[] name)
    {
        this.context=context;
        this.lid=lid;
        this.name=name;
        this.date=date;
        this.time=time;
        this.longitude=longitude;
        this.latitude=latitude;
        this.emergency_id=emergency_id;
    }
    @Override
    public int getCount() {
        return lid.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View flv;

        if (view==null)
        {
            flv=inflater.inflate(R.layout.custom_view_emergency,null);
        }else{
            flv=(View) view;
        }
        TextView tvdate = flv.findViewById(R.id.textView19);
        TextView tvtime = flv.findViewById(R.id.textView20);
        TextView tvuser = flv.findViewById(R.id.textView21);
        Button loc = flv.findViewById(R.id.button16);
//        TextView tvlatitude = flv.findViewById(R.id.textView18);
        tvdate.setText(date[i]);
        tvtime.setText(time[i]);
        tvuser.setText(name[i]);

        loc.setTag(latitude[i]+","+longitude[i]);
        loc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String location = "https://maps.google.com/?q="+view.getTag().toString();
                context.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(location)).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            }
        });

        return flv;
    }
}
