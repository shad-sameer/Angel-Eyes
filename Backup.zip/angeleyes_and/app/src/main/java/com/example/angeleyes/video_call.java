package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class video_call extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_call);
    }
}