package com.example.angeleyes;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class custom_view_feedback extends BaseAdapter {
    String[] feedback_id,date,lid,feedbacks;
    Context context;
    public custom_view_feedback(Context context,String[]feedback_id,String[] date,String[] lid,String[]feedbacks)
    {
        this.context=context;
        this.lid=lid;
        this.feedback_id=feedback_id;
        this.date=date;
        this.feedbacks=feedbacks;

    }
    @Override
    public int getCount() {
        return feedback_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {


        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View flv;

        if (view==null)
        {
            flv=inflater.inflate(R.layout.custom_view_feedback,null);
        }else{
            flv=(View) view;
        }
        TextView tvdate = flv.findViewById(R.id.textView7);
        TextView tvfeed = flv.findViewById(R.id.textView8);

        tvdate.setText(date[i]);
        tvfeed.setText(feedbacks[i]);

        return flv;
    }
}
