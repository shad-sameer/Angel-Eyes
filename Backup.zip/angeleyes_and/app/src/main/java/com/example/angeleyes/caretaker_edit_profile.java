package com.example.angeleyes;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

public class caretaker_edit_profile extends AppCompatActivity implements View.OnClickListener {
    EditText ed_name,ed_place,ed_pincode,ed_phone,ed_dob,ed_email,ed_housename,ed_district,ed_post;
    RadioGroup rg;
    RadioButton male,female,others;
    Button btn_signup;
    ImageView img;
    String path, atype, fname, attach;
    byte[] byteArray = null;
    String gender;



    @Override
    public void onBackPressed() {
        Intent ij=new Intent(getApplicationContext(),Vgome.class);
        startActivity(ij);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker_sign_up);
        ed_name=findViewById(R.id.editTextTextPersonName23);
        ed_place=findViewById(R.id.editTextTextPersonName24);
        ed_pincode=findViewById(R.id.editTextTextPersonName25);
        ed_phone=findViewById(R.id.editTextPhone3);
        ed_dob=findViewById(R.id.editTextDate3);
        ed_email=findViewById(R.id.editTextTextEmailAddress3);
        ed_housename=findViewById(R.id.editTextTextPersonName27);
        ed_district=findViewById(R.id.editTextTextPersonName26);
        ed_post=findViewById(R.id.editTextTextPostalAddress3);
        rg=findViewById(R.id.radioGroup2);
        male=findViewById(R.id.radioButton2);
        female=findViewById(R.id.radioButton3);
        others=findViewById(R.id.radioButton5);
        btn_signup=findViewById(R.id.button8);
        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

        ed_name.setText(sh.getString("name",""));
        ed_district.setText(sh.getString("district",""));
        ed_place.setText(sh.getString("place",""));
        ed_pincode.setText(sh.getString("pincode",""));
        ed_phone.setText(sh.getString("phone",""));
        ed_dob.setText(sh.getString("dob",""));
        ed_email.setText(sh.getString("email",""));
        ed_housename.setText(sh.getString("housename",""));
        ed_post.setText(sh.getString("post",""));




        img=findViewById(R.id.imageView4);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showfilechooser(1);
            }
        });
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(male.isChecked()){
                    gender="Male";
                }if(female.isChecked()){
                    gender="Female";
                }if(others.isChecked()){
                    gender="Others";
                }
            }
        });


        btn_signup.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        final String name=ed_name.getText().toString();
        final String place=ed_place.getText().toString();
        final String pincode=ed_pincode.getText().toString();
        final String phone=ed_phone.getText().toString();
        final String dob=ed_dob.getText().toString();
        final String email=ed_email.getText().toString();
        final String housename=ed_housename.getText().toString();
        final String district=ed_district.getText().toString();
        final String post=ed_post.getText().toString();

        if(name.length()==0){
            ed_name.setError("Missing");
        }
        else if(place.length()==0){
            ed_place.setError("Missing");
        }
        else if(pincode.length()==0){
            ed_pincode.setError("Missing");
        }
        else if(phone.length()==0){
            ed_phone.setError("Missing");
        }
        else if(dob.length()==0){
            ed_dob.setError("Missing");
        }
        else if(email.length()==0){
            ed_email.setError("Missing");
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            ed_email.setError("Invalid mail format");
        }
        else if(housename.length()==0){
            ed_housename.setError("Missing");
        }
        else if(district.length()==0){
            ed_district.setError("Missing");
        }
        else if(post.length()==0){
            ed_post.setError("Missing");
        }
        else {
            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

            String hu = sh.getString("ip", "");
            String url = "http://" + hu + ":5000/careaker_edit_profile";


            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                            // response
                            try {
                                JSONObject jsonObj = new JSONObject(response);
                                if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                    Toast.makeText(caretaker_edit_profile.this, "Success", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(), MainActivity.class));
                                }

                                // }
                                else {
                                    Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "welcome" + error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("name", name);
                    params.put("place", place);
                    params.put("pincode", pincode);
                    params.put("phone", phone);
                    params.put("dateofbirth", dob);
                    params.put("email", email);
                    params.put("housename", housename);
                    params.put("district",district);
                    params.put("post", post);
                    params.put("gender", gender);
                    params.put("picture", attach);
                    params.put("lid", sh.getString("lid",""));

                    return params;
                }
            };

            int MY_SOCKET_TIMEOUT_MS = 100000;

            postRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(postRequest);
        }
    }
    void showfilechooser(int string) {
        // TODO Auto-generated method stub
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        //getting all types of files

        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), string);
        } catch (android.content.ActivityNotFoundException ex) {
            // Potentially direct the user to the Market with a Dialog
            Toast.makeText(getApplicationContext(), "Please install a File Manager.", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                ////
                Uri uri = data.getData();

                try {
                    path = FileUtils.getPath(this, uri);

                    File fil = new File(path);
                    float fln = (float) (fil.length() / 1024);
                    atype = path.substring(path.lastIndexOf(".") + 1);


                    fname = path.substring(path.lastIndexOf("/") + 1);

                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

                try {

                    File imgFile = new File(path);

                    if (imgFile.exists()) {

                        Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                        img.setImageBitmap(myBitmap);

                    }


                    File file = new File(path);
                    byte[] b = new byte[8192];
                    Log.d("bytes read", "bytes read");

                    InputStream inputStream = new FileInputStream(file);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();

                    int bytesRead = 0;

                    while ((bytesRead = inputStream.read(b)) != -1) {
                        bos.write(b, 0, bytesRead);
                    }
                     byteArray = bos.toByteArray();

                    String str = Base64.encodeToString(byteArray, Base64.NO_WRAP);
                    attach = str;


                } catch (Exception e) {
                    Toast.makeText(this, "String :" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }

                ///

            }
        }

    }
}

