package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText ip;
    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ip = findViewById(R.id.editTextTextPersonName16);
        btn = findViewById(R.id.button5);
        btn.setOnClickListener(this);
        SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        ip.setText(sh.getString("ip",""));
    }

    @Override
    public void onClick(View view) {
        String ipa=ip.getText().toString();
        String url="http://" + ipa + ":5000";
        if(ipa.length()==0){
            ip.setError("missing");
        }
        else{
            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
SharedPreferences.Editor ed= sh.edit();
ed.putString("ip",ipa);
ed.putString("url",url);
ed.commit();

Intent ij=new Intent(getApplicationContext(),login.class);
startActivity(ij);

        }
    }
}