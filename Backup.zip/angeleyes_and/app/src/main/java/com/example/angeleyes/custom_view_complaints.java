package com.example.angeleyes;

        import android.content.Context;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.BaseAdapter;
        import android.widget.TextView;

public class custom_view_complaints extends BaseAdapter {
    String[] complaint_id,lid,date,status,reply,complaint;
    Context context;
    public custom_view_complaints(Context context,String[] complaint_id,String[] lid,String[] date,String[] status,String[]reply,String[] complaint)
    {
        this.context=context;
        this.complaint_id=complaint_id;
        this.lid=lid;
        this.date=date;
        this.status=status;
        this.reply=reply;
        this.complaint=complaint;
    }
    @Override
    public int getCount() {
        return complaint_id.length;
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View flv;

        if (view==null)
        {
            flv=inflater.inflate(R.layout.custom_view_complaints,null);
        }else{
            flv=(View) view;
        }
        TextView tvdate = flv.findViewById(R.id.editTextTextPersonName18);
        TextView tvstatus = flv.findViewById(R.id.editTextTextPersonName19);
        TextView tvlreply = flv.findViewById(R.id.editTextTextPersonName20);
        TextView tvcomplaint = flv.findViewById(R.id.editTextTextPersonName21);
        tvdate.setText(date[i]);
        tvstatus.setText(status[i]);
        tvlreply.setText(reply[i]);
        tvcomplaint.setText(complaint[i]);
        return flv;
    }
}
