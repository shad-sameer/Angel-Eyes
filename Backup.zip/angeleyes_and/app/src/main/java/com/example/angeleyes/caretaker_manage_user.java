package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class caretaker_manage_user extends AppCompatActivity implements View.OnClickListener {

    ImageView careimage;
    EditText carename, carplace, carepincode, carephone, carepost, caredist, carehouse, caredob, caremail;
    RadioButton r1,r2;
    Button btn;
    String path, atype, fname, attach, attatch1;
    byte[] byteArray = null;
    String gender="";
    final Calendar myCalendar= Calendar.getInstance();


    @Override
    public void onBackPressed() {
        Intent ij=new Intent(getApplicationContext(),Vgome.class);
        startActivity(ij);
    }



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caretaker_manage_user);
        careimage = findViewById(R.id.imageButton);
        careimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showfilechooser(1);
            }
        });
        carename = findViewById(R.id.editTextTextPersonName4);
        carplace = findViewById(R.id.editTextTextPersonName6);
        carepincode = findViewById(R.id.editTextTextPersonName7);
        carephone = findViewById(R.id.editTextTextPersonName8);
        carepost = findViewById(R.id.editTextTextPersonName10);
        caredist = findViewById(R.id.editTextTextPersonName11);
        carehouse = findViewById(R.id.editTextTextPersonName12);
        caredob = findViewById(R.id.dob);
        caremail = findViewById(R.id.editTextTextPersonName29);
        r1=findViewById(R.id.radioButton10);
        r2=findViewById(R.id.radioButton11);
        btn = findViewById(R.id.button4);
        btn.setOnClickListener(this);
        caredob.setOnClickListener(this);




        DatePickerDialog.OnDateSetListener date =new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH,month);
                myCalendar.set(Calendar.DAY_OF_MONTH,day);
                updateLabel();
            }
        };
        caredob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Calendar c= Calendar.getInstance();
                c.add(Calendar.YEAR,-18);
                DatePickerDialog d= new DatePickerDialog(caretaker_manage_user.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH), myCalendar.get(Calendar.DAY_OF_MONTH));
                d.getDatePicker().setMaxDate(c.getTimeInMillis());
                d.show();

//                new DatePickerDialog(caretaker_manage_user.this,date,myCalendar.get(Calendar.YEAR),myCalendar.get(Calendar.MONTH),myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });


    }

    @Override
    public void onClick(View view) {
        String name = carename.getText().toString();
        String place = carplace.getText().toString();
        String pincode = carepincode.getText().toString();
        String phone = carephone.getText().toString();
        String post = carepost.getText().toString();
        String dist = caredist.getText().toString();
        String house = carehouse.getText().toString();
        String dob = caredob.getText().toString();
        String email = caremail.getText().toString();

        if(r1.isChecked()){

            gender=r1.getText().toString();

        }
        else{

            gender=r2.getText().toString();


        }



        if (name.length() == 0) {
            carename.setError("missing");
        } else if (place.length() == 0) {
            carplace.setError("missing");
        } else if (pincode.length()!=6) {
            carepincode.setError("missing");
        } else if (phone.length()!=12) {
            carephone.setError("missing");
        } else if (post.length() == 0) {
            carepost.setError("missing");
        } else if (dist.length() == 0) {
            caredist.setError("missing");
        } else if (house.length() == 0) {
            carehouse.setError("missing");
        } else if (dob.length() == 0) {
            caredob.setError("missing");
        }  else if (email.length() == 0) {
            caremail.setError("missing");
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            caremail.setError("Invalid mail format");
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            caremail.setError("Enter Valid Email");
            caremail.requestFocus();
        }
        else
        {
            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

            final String maclis = sh.getString("mac_list", "");
            String uid = sh.getString("uid", "");
            String hu = sh.getString("ip", "");
            String url = sh.getString("url", "") + "/add_user";


            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                            // response
                            try {
                                JSONObject jsonObj = new JSONObject(response);
                                if (jsonObj.getString("status").equalsIgnoreCase("ok")) {
                                    startActivity(new Intent(getApplicationContext(), view_user.class));
                                    Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_LONG).show();


                                }


                                // }
                                else {
                                    Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                }

                            } catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("lid", sh.getString("lid",""));

                    params.put("user_name", name);
                    params.put("place", place);
                    params.put("pincode", pincode);
                    params.put("phone", phone);
                    params.put("post", post);
                    params.put("dist", dist);
                    params.put("house", house);
                    params.put("dob", dob);
                    params.put("gender", gender);
                    params.put("email", email);
                    params.put("photo", attach);

                    return params;
                }
            };

            int MY_SOCKET_TIMEOUT_MS = 100000;

            postRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(postRequest);
        }
    }

    void showfilechooser(int string) {
        // TODO Auto-generated method stub
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        //getting all types of files

        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try {
            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), string);
        } catch (android.content.ActivityNotFoundException ex) {
            // Potentially direct the user to the Market with a Dialog
            Toast.makeText(getApplicationContext(), "Please install a File Manager.", Toast.LENGTH_SHORT).show();

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                ////
                Uri uri = data.getData();

                try {
                    path = FileUtils.getPath(this, uri);

                    File fil = new File(path);
                    float fln = (float) (fil.length() / 1024);
                    atype = path.substring(path.lastIndexOf(".") + 1);


                    fname = path.substring(path.lastIndexOf("/") + 1);
                } catch (URISyntaxException e) {
                    e.printStackTrace();
                }

                try {

                    File imgFile = new File(path);

                    if (imgFile.exists()) {

                        Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                        careimage.setImageBitmap(myBitmap);

                    }


                    File file = new File(path);
                    byte[] b = new byte[8192];
                    Log.d("bytes read", "bytes read");

                    InputStream inputStream = new FileInputStream(file);
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();

                    int bytesRead = 0;

                    while ((bytesRead = inputStream.read(b)) != -1) {
                        bos.write(b, 0, bytesRead);
                    }
                    byteArray = bos.toByteArray();

                    String str = Base64.encodeToString(byteArray, Base64.NO_WRAP);
                    attach = str;


                } catch (Exception e) {
                    Toast.makeText(this, "String :" + e.getMessage().toString(), Toast.LENGTH_LONG).show();
                }

                ///

            }
        }
//        else{
        ActivityCompat.requestPermissions(caretaker_manage_user.this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, requestCode);
//
//        }

    }



        private void updateLabel(){
            String myFormat="dd/MM/yy";
            SimpleDateFormat dateFormat=new SimpleDateFormat(myFormat, Locale.US);

            caredob.setText(dateFormat.format(myCalendar.getTime()));
        }




}
