package com.example.angeleyes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class add_user extends AppCompatActivity implements View.OnClickListener {
    EditText ed_username,ed_address,ed_phone,ed_dob,ed_email;
    Button btn_signup;
    RadioGroup rg;
    RadioButton male,female;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_user);
        ed_username=findViewById(R.id.editTextTextPersonName22);
        ed_address=findViewById(R.id.editTextTextPostalAddress);
        ed_phone=findViewById(R.id.editTextPhone);
        ed_dob=findViewById(R.id.editTextDate);
        ed_email=findViewById(R.id.editTextTextEmailAddress);
        btn_signup=findViewById(R.id.button9);
        rg=findViewById(R.id.radioGroup);
        male=findViewById(R.id.radioButton);
        female=findViewById(R.id.radioButton4);
        img=findViewById(R.id.imageView3);
        btn_signup.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        final String name=ed_username.getText().toString();
        final String address=ed_address.getText().toString();
        final String phone=ed_phone.getText().toString();
        final String dob=ed_dob.getText().toString();
        final String email=ed_email.getText().toString();

        if(name.length()==0){
            ed_username.setError("Missing");

        }
        else if(address.length()==0){
            ed_address.setError("Missing");

        }
        else if(phone.length()!=10){
            ed_phone.setError("Missing");
        }
        else if(dob.length()==0){
            ed_dob.setError("Missing");
        }
        else if(email.length()==0){
            ed_email.setError("Missing");
        }
        else
        {
            SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());

            final String maclis=sh.getString("mac_list","");
            String uid=sh.getString("uid","");
            String hu = sh.getString("ip", "");
            String url = sh.getString("url", "")+"/add_user";



            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
            StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            //  Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();

                            // response
                            try {
                                JSONObject jsonObj = new JSONObject(response);
                                if (jsonObj.getString("status").equalsIgnoreCase("ok")) {


                                }


                                // }
                                else {
                                    Toast.makeText(getApplicationContext(), "Not found", Toast.LENGTH_LONG).show();
                                }

                            }    catch (Exception e) {
                                Toast.makeText(getApplicationContext(), "Error" + e.getMessage().toString(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            // error
                            Toast.makeText(getApplicationContext(), "eeeee" + error.toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() {
                    SharedPreferences sh = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("name",name);
                    params.put("address",address);
                    params.put("number",phone);
                    params.put("dob",dob);
                    params.put("email",email);

                    return params;
                }
            };

            int MY_SOCKET_TIMEOUT_MS=100000;

            postRequest.setRetryPolicy(new DefaultRetryPolicy(
                    MY_SOCKET_TIMEOUT_MS,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                    DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
            requestQueue.add(postRequest);
        }


    }
}